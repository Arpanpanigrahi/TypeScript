// @Component({})  // @Component is decorators
// class Component {
//     constructor(public name : string) { }

// }