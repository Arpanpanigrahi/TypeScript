let fname = 'test';

fname = 10;
